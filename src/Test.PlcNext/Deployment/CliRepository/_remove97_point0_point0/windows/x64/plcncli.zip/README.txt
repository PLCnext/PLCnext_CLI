﻿------------
Prerequisite
------------

+ CMake ver. 3.7+ available in a PATH like environment variable
+ PlcNext SDK(s) installed

---------------------
How to setup the CLIF
---------------------

+ Copy the content of the 'SDKFiles' directory to all installed SDKs
+ For each SDK in the SDk root folder in the 'manifest.xml' add all supported targets of the SDK
+ Add for each SDK one entry to the 'settings.xml'

----------------------------------
Example on how to create a library
----------------------------------

<Path to command> new project -n My.Company.Product --target AXCF2152
<Path to command> generate meta -p .\My.Company.Product\
<Path to command> build -p .\My.Company.Product\

--------------------------------------
How to define a component/program port
--------------------------------------

+ Place a comment above the field of the port
+ The comment need to have the format '//#port(<attributes>)'
	+ Everything inside the bracket will be used as attributes for the port,
	  such as INPUT
	+ '//#port' is also valid; than the port will have no attributes
+ The port field need to be at least protected

----
Misc
----

Q.	What is the '//#component(<Name of a component>)' comment above the class
definition of a program?

A.	It defines the component which manages the program. It can be changed to
change the managing component. If no such comment is found, the last namespace
will be used as the name for the managing component.

Q.	Why is my component named 'MyComponentImpl' although I named it
'MyComponent'?

A.	This will change in the future. For now it is necessary for the code
generation. The name of the component is 'MyComponent' in the library and in
the '//#component' comment for programs.

Q.	Can I change the prefix '#' for all markings such as '#port' and
'#component'?

A.	Yes. In the 'settings.xml' is an attribute called 'AttributePrefix'. This
value is used to define the prefix. Warning: This setting applies to all
projects. All attributes need to be changed accordingly.